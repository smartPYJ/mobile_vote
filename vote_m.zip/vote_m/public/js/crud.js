
var firebaseConfig = {
    apiKey: "AIzaSyDiyITlwAF6nUBqTcTN9SKVcFozN9FJse8",
    authDomain: "crutechdecide.firebaseapp.com",
    databaseURL: "https://crutechdecide.firebaseio.com",
    projectId: "crutechdecide",
    storageBucket: "crutechdecide.appspot.com",
    messagingSenderId: "688196103176",
    appId: "1:688196103176:web:5a2342bada81a1d03635bd",
    measurementId: "G-222ZRFNLC0"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);


function createStudent() {
    var user_email = document.getElementById("email").value;
    var user_password = document.getElementById("password").value;

    firebase.auth().createUserWithEmailAndPassword(user_email, user_password).catch(function (error) {
        // Handle Errors here.

        window.alert("Error " + errorMessage);
    });
    var user = firebase.auth().currentUser.uid;
    



    var path = user;
    var data = {
        name: document.getElementById("name").value,
        lastname: document.getElementById("lastname").value,
        department: document.getElementById("department").value,
        faculty: document.getElementById("faculty").value,
        level: document.getElementById("level").value,
        regnumber: document.getElementById("regnumber").value,
        uid: user,
        vote: document.getElementById("vote").value,
        feedback: document.getElementById("feedback").value
    }

    console.log(path + data);


    let db = firebase.database().ref("Student/" + path);
    db.set(data);





    window.alert("Student uploaded");
    document.getElementById("regnumber").value = "";
    document.getElementById("name").value = "";
    document.getElementById("lastname").value = "";
    document.getElementById("department").value = "";
    document.getElementById("faculty").value = "";
    document.getElementById("level").value = "";
    document.getElementById("vote").value = "";
    document.getElementById("feedback").value = "";
    document.getElementById("email").value = "";
}


function createcandidate() {




    var path = document.getElementById("regnumber").value;
    var name = document.getElementById("name");
    var lastname = document.getElementById("lastname");
    var full_name = (name.value + "  " + lastname.value);
    var data = {

        fullname: (full_name),
        department: document.getElementById("department").value,
        position: document.getElementById("post").value,
        faculty: document.getElementById("faculty").value,


    }

    console.log(path + data);
    let db = firebase.database().ref("candidate/" + path);
    db.set(data)
    window.alert("Candidate uploaded");

    document.getElementById("regnumber").value = "";
    document.getElementById("name").value = "";
    document.getElementById("lastname").value = "";
    document.getElementById("department").value = "";
    document.getElementById("faculty").value = "";
    document.getElementById("post").value = "";
}


function candidate() {
    document.getElementById();
}

function update_student() {
    //update student record 
    document.getElementById("name").value = "test";
    document.getElementById("lastname").value = "test";
    document.getElementById("department").value = "test";
    document.getElementById("regnumber").value = "test";
    document.getElementById("faculty").value = "test";

}
function upadtecandidate() {
    // update candidate record
}




function delete_student() {
    // delete student from the database 
    var stu_reg = document.getElementById("regnumber").value;
    let stu_ref = firebase.database().ref('Student/' + stu_reg);
    stu_ref.remove()
    window.alert("Student with reg_number " + stu_reg + " have been removed from the database ");
    document.getElementById("regnumber").value = "";
}

function delete_candidate() {
    // delete candidate from the database 
    var can_reg = document.getElementById("can_reg_number").value;
    let can_ref = firebase.database().ref('candidate/' + can_reg);
    can_ref.remove()
    window.alert("Candidate with reg_number  " + can_reg + " have been removed from the database ");
    document.getElementById("can_reg_number").value = "";
}



