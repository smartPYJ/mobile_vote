
var firebaseConfig = {
    apiKey: "AIzaSyDiyITlwAF6nUBqTcTN9SKVcFozN9FJse8",
    authDomain: "crutechdecide.firebaseapp.com",
    databaseURL: "https://crutechdecide.firebaseio.com",
    projectId: "crutechdecide",
    storageBucket: "crutechdecide.appspot.com",
    messagingSenderId: "688196103176",
    appId: "1:688196103176:web:5a2342bada81a1d03635bd",
    measurementId: "G-222ZRFNLC0"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

var ref = firebase.database().ref("Student/uid");
ref.once("value")
    .then(function (snapshot) {
        var a = snapshot.numChildren(); 
        document.getElementById("studentcount").innerHTML = "2";

       // document.getElementById("studentcount").innerHTML = "2";
    });
