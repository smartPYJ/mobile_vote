

// Initialize Firebase
var config = {
    apiKey: "AIzaSyDiyITlwAF6nUBqTcTN9SKVcFozN9FJse8",
    authDomain: "crutechdecide.firebaseapp.com",
    databaseURL: "https://crutechdecide.firebaseio.com",
    projectId: "crutechdecide",
    storageBucket: "crutechdecide.appspot.com",
    messagingSenderId: "688196103176",
    appId: "1:688196103176:web:5a2342bada81a1d03635bd",
    measurementId: "G-222ZRFNLC0"
};
firebase.initializeApp(config);

firebase.auth().onAuthStateChanged(function (user) {
    if (user) {

        document.getElementById("home").style.display = "block";
        document.getElementById("user").style.display = "none";

    } else {

        document.getElementById("home").style.display = "none";
        document.getElementById("user").style.display = "block";
    }


});



function login() {
    var useremail = document.getElementById("useremail").value;
    var userpass = document.getElementById("password").value;

    firebase.auth().signInWithEmailAndPassword(useremail, userpass).catch(function (error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        // ...
        window.alert("wrong  info" + errorMessage);
        console.log(errorMessage);

    });

}

function logout() {

    firebase.auth().signOut();
    window.alert("logged out successful ");
    document.getElementById("home").style.display = "none";
    document.getElementById("user").style.display = "block";


}



function create() {
    var user_email = document.getElementById("useremail").value;
    var user_password = document.getElementById("userpass").value;
    var confrom_password = document.getElementById("userpass2").value;
    if (user_password == confrom_password) {

        firebase.auth().createUserWithEmailAndPassword(user_email, user_password).catch(function (error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            // ...
            window.alert("Error " + errorMessage);
        });

        var user = firebase.auth().currentUser;




        user.sendEmailVerification().then(function () {
            // Email sent.
            window.alert("Verification url sent.");
        }).catch(function (error) {
            // An error happened.
            window.alert("Error " + errorMessage);
        });


    } else {
        window.alert("Password and Confrom Password dose not Match for " + user_email);
    }
}