function check_empty(){
    if (document.getElementById('name').value =="" || document.getElementById('department').value == "" || document.getElementById('regumber').value == ""){

        alert("Fill all Fields !");
    } else {
        document.getElementById('form').submit();

    }
}
// function to display popup
function div_show(){
    document.getElementById('register').style.display = "block";
}

// Function to hide popup
function div_hide(){
    document.getElementById('register').style.display ="none"
}